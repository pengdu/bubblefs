#!/bin/sh

export MALLOC_CONF="prof:true,lg_prof_sample:0"
