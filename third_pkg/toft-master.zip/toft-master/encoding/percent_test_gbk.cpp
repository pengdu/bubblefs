// Copyright (c) 2011, The Toft Authors
// All rights reserved.

/// @file percent_test_gbk.cpp
/// @brief
/// @date  03/31/2011 04:13:48 PM
/// @author CHEN Feng <chen3feng@gmail.com>

const char kTigerGBK[] = "�ϻ����Ӽ�";
const char kTigerGBKEncoded[] = "%C0%CF%BB%A2%B0%F4%D7%D3%BC%A6";
