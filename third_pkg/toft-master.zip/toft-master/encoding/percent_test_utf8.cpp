// Copyright (c) 2011, The Toft Authors
// All rights reserved.

/// @file percent_test_utf8.cpp
/// @brief
/// @date  03/31/2011 04:13:48 PM
/// @author CHEN Feng <chen3feng@gmail.com>

const char kTigerUtf8[] = "老虎棒子鸡";
const char kTigerUtf8Encoded[] = "%E8%80%81%E8%99%8E%E6%A3%92%E5%AD%90%E9%B8%A1";
