// Copyright (c) 2013, The TOFT Authors.
// All rights reserved.
//
// Author: CHEN Feng <chen3feng@gmail.com>
// Created: 2013-02-28

#ifndef TOFT_BASE_TYPE_TRAITS_STD_H
#define TOFT_BASE_TYPE_TRAITS_STD_H
#pragma once

#include <type_traits>

#endif // TOFT_BASE_TYPE_TRAITS_STD_H
