// Copyright (c) 2013, The TOFT Authors.
// All rights reserved.
//
// Author: CHEN Feng <chen3feng@gmail.com>
// Created: 2013-02-28

#ifndef TOFT_BASE_TYPE_TRAITS_ADD_MISSING_H
#define TOFT_BASE_TYPE_TRAITS_ADD_MISSING_H
#pragma once

#include "toft/base/type_traits/enable_if.h"
#include "toft/base/type_traits/make_signness.h"

#endif // TOFT_BASE_TYPE_TRAITS_ADD_MISSING_H
