// Copyright (c) 2013, The Toft Authors.
// All rights reserved.
//
// Author: CHEN Feng <chen3feng@gmail.com>
// Created: 2013-04-02
// Description:

#include "toft/system/process/process_local_const.h"

namespace toft {

TOFT_DEFINE_LINKING_ASSERT(ProcessLocalConst);

} // namespace toft

