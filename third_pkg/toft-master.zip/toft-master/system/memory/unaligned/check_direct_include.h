// Copyright (c) 2010, The TOFT Authors.
// All rights reserved.
//
// Author: CHEN Feng <chen3feng@gmail.com>

// No inclusion guard needed
// GLOBAL_NOLINT(build/header_guard)

#ifndef TOFT_SYSTEM_MEMORY_UNALIGNED_H
#error "internal header, never use directly. include toft/system/memory/unaligned.h instead."
#endif
