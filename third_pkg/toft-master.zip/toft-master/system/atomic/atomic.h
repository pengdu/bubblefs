// Copyright (c) 2012, The Toft Authors.
// All rights reserved.
//
// Author: CHEN Feng <chen3feng@gmail.com>

#ifndef TOFT_SYSTEM_ATOMIC_ATOMIC_H
#define TOFT_SYSTEM_ATOMIC_ATOMIC_H
#pragma once

#include "toft/system/atomic/functions.h"
#include "toft/system/atomic/type.h"

#endif // TOFT_SYSTEM_ATOMIC_ATOMIC_H
