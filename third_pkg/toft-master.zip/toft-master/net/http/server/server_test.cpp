// Copyright (c) 2013, The Toft Authors.
// All rights reserved.
//
// Author: CHEN Feng <chen3feng@gmail.com>

#include "toft/net/http/server/server.h"
#include "thirdparty/gtest/gtest.h"

namespace toft {

TEST(HttpServer, Ctor) {
    HttpServer server;
}

} // namespace toft
