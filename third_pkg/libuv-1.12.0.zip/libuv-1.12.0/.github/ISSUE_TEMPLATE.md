<!--
If you want to report a bug, you are in the right place!

If you need help or have a question, go here: https://github.com/libuv/help/new

Please include code that demonstrates the bug and keep it short and simple.
-->
* **Version**: <!-- libuv version -->
* **Platform**: <!-- `uname -a` (UNIX), or Windows version and machine type -->
