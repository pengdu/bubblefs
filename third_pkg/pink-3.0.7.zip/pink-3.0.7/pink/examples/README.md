myproto.proto  the proto buffer file used to test pb protocol

myholy_srv.cc  server side of myproto.proto with holy thread

mydispatch_srv.cc  server side of myproto.proto with dispatch thread and worker thread

myproto_cli.cc  client support myproto.proto

myredis_srv.cc A simple server support redis protocol, it can be used to test the performance of pink with redis protocol  

performance/  client and server code used to get performance benchmark
