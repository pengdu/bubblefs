#ifndef SLASH_DEFINE_H_
#define SLASH_DEFINE_H_

#define SPACE ' '
#define COLON ':'
#define COMMENT '#'
#define COMMA ','


#endif
