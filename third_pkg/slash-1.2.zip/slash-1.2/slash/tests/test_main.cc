#include "slash/include/slash_testharness.h"

int main() {
  return slash::test::RunAllTests();
}
