# Slash: C++ library

[![Build Status](https://travis-ci.org/Qihoo360/slash.svg?branch=master)](https://travis-ci.org/Qihoo360/slash)

## Composition

* File utils;
* configuration utils;
* mutex utils;
* simple log utils;
* string utils;
* simple hash utils;
* coding utils;
* binlog utils;
* unit test utils;
* environment utils;
