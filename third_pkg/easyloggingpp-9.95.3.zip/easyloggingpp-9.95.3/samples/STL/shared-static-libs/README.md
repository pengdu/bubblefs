## A Simple example of shared and static compilations

```
.
├── compile_shared.sh
├── compile_static.sh
├── lib
│   ├── include
│   │   ├── easylogging++.h
│   │   └── mylib.hpp
│   └── mylib.cpp
└── myapp.cpp

2 directories, 6 files
```
