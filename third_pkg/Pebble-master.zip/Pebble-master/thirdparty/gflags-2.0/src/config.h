#ifdef WIN32
// windows system
#include "./windows/config.h"
#else
// linux system
#include "config_linux.h"
#endif
