./configure --enable-shared=no --with-pic=yes 

make

make install
