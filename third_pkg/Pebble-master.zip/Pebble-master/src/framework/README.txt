pebble framework
----------------------------------
本目录放置pebble框架核心内容，主要包括pebble的机制定义和实现，如message、processor、rpc、路由、名字、统计、过载保护、广播、并发等接口定义和机制实现
framework仅依赖pebble common库，可以很方便的进行扩展。


    pebble framework
  -------------------
     pebble common


