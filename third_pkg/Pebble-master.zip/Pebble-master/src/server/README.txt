pebble server
----------------------------------
本目录为Pebble框架后台server的参考实现，具备基本的程序框架、命令行、控制命令等能力
pebble server只依赖pebble framework，但是可以pebble extension配合使用

                 user application
    --------------------------------------------
        pebble server     |  pebble extension
    --------------------------------------------
      pebble framework
    ----------------------|
        pebble common     |  zookeeper tbuspp


