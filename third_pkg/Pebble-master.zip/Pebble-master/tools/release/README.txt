发布：
1. trunk/目录下各模块编译通过
2. 执行trunk/tools/release下copy_release.sh拷贝必要文件到trunk/release目录
3. 确认trunk/release/x86_64/example下各个例子可编译通过后，可用pack_release.sh打包

