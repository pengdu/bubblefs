#!/bin/sh

../build/release/bin/saber_client_main 127.0.0.1:6666,127.0.0.1:6667,127.0.0.1:6668
