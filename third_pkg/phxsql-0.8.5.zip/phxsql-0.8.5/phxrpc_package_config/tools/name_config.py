
phxbinlogsvr='phxbinlogsvr_phxrpc'
phxsqlproxy='phxsqlproxy_phxrpc'
phxsync_plugin='phxsync_master_phxrpc.so'


